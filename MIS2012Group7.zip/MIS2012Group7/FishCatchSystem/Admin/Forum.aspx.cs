﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FishCatchSystem.Member
{
    public partial class Forum : System.Web.UI.Page
    {

    }
}