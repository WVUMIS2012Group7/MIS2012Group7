﻿CKEDITOR.plugins.setLang("bbcodeselector","en",{
  bbcodeselector:
    {
	 title:"Add a Custom BBCode",
	 bbCodeLbl:"Select YAF BBCode:",
	 userLink:"Enter a User Name in Here",
	 spoiler:"Enter Spoiler Text in here",
	 googlewidget:"<script src=\"Enter the Url to the Widget here\"></script>",
	 vimeo:"http://www.vimeo.com/xxxxxxx",
	 youtube:"http://www.youtube.com/watch?v=xxxxxxxx"
	}
});